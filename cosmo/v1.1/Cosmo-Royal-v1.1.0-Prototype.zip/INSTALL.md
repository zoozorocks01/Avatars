# Cosmo Royal V1.1

An unofficial royal-blue Cosmo fan-created desktop pet: athletic gait, basketball backflip, playbook reading, and directional gaze. Version **1.1.0**, downloadable prototype.

[Download Cosmo Royal V1.1](https://github.com/zoozorocks01/Avatars/raw/refs/heads/main/cosmo/v1.1/Cosmo-Royal-v1.1.0-Prototype.zip) · [Release notes](RELEASE-NOTES.md) · [Checksum manifest](https://github.com/zoozorocks01/Avatars/blob/main/cosmo/v1.1/manifest.json)

![Cosmo running](preview.gif)
![Cosmo flipping](flip-preview.gif)

## Install

1. Download and unzip the package. No GitHub login, API key, or executable installer is needed.
2. In a compatible desktop app, open **Settings → Pets → Custom pets → Open folder**, if available. Menu names may differ. The Mac default observed during development is `~/.codex/pets/`; prefer the app's folder control.
3. Copy the extracted **cosmo-royal-v1** folder into the custom-pet folder. It contains only `pet.json` and `spritesheet.webp`.
4. Refresh the pet list, select **Cosmo Royal**, and show/wake him if hidden. If cached artwork persists, select another pet and return to Cosmo. Save your work before restarting the app yourself if needed.

This is a folder-based install, not a verified one-click ZIP import. If your app lacks local custom pets, stop and check compatibility. Other operating systems have not been verified.

## Update or roll back

Keep the stable folder **cosmo-royal-v1**, including for future versions. Before updating, back up its existing two files together **outside** the active pets folder. Replace only those two files, then refresh/reselect Cosmo. Preserve local customizations and other pets. To roll back, restore the backed-up pair and refresh/reselect.

Updates are requested by you; no automatic updater or scheduler is included. [catalog.json](https://github.com/zoozorocks01/Avatars/blob/main/catalog.json) identifies the latest version and manifest.

## Ask an agent

> Install or update Cosmo Royal from https://github.com/zoozorocks01/Avatars using AGENT-INSTALL.md. Resolve a single commit, verify the manifest and both file hashes, and back up any existing Cosmo before replacement. Honor my host's approval rules. Ask me to refresh/select Cosmo if app control is blocked.

See the [agent guide](AGENT-INSTALL.md) for the complete procedure.

## Prototype checks

Atlas validation, ordered-frame visual review, and local installation/readback passed. Timed visual and live-app playback of this version remain unverified. Some joints remain stylized and the compact flip has minor proportion variation.

After activation, check left/right movement, the flip, return to standing, and work/playbook actions when the app triggers them. Following typed text is not necessarily global mouse tracking. Reduced Motion may limit animation; change that preference only if you choose to.

This project is not affiliated with or endorsed by BYU or OpenAI. No ownership of third-party names, mascots, or marks is claimed.
